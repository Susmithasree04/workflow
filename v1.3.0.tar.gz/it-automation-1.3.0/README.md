# Exastro IT Automation

Exastro IT Automation is a software that achieves following goals:

  * Centralized parameter management
  * Automated system build with specific parameters
