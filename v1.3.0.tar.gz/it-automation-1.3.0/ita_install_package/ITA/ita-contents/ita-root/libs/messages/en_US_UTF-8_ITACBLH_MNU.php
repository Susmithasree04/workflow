<?php
//   Copyright 2019 NEC Corporation
//
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License.
//
////en_US_UTF-8_ITACBLH_MNU
$ary[1001] = "You can perform maintenance (view/register/update/discard) of interface information for Cobbler server. <br>This menu should be one record.";
$ary[1004] = "No.";
$ary[1002] = "Cobbler interface information";
$ary[1003] = "Cobbler interface information";
$ary[1005] = "Data relay storage path (ITA)";
$ary[1006] = "Display order";
$ary[1007] = "";
$ary[1008] = "Specify the shared directory with Cobbler server.";
$ary[1009] = "It is possible to view the profile list that is replicated periodically from the Cobbler server.";
$ary[1010] = "No.";
$ary[1011] = "Cobbler profile list";
$ary[1012] = "Cobbler profile list";
$ary[1013] = "Profile name";
$ary[1014] = "[Maximum length] 256 bytes";
$ary[1015] = "Display order";
$ary[1016] = "";
?>